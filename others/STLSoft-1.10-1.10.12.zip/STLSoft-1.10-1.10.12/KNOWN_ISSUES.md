# STLSoft - Known Issues:

## STLSoft 1.10 Known Issues:

* The documentation is still lacking. This will be addressed in the release of 1.11.

* Several `unixstl::system_traits` methods are declared but not defined, with the intention to flesh them out from Linux system calls (and have emulations/workarounds for other architectures). We're keen to see pull-requests on this.


<!-- ########################### end of file ########################### -->

