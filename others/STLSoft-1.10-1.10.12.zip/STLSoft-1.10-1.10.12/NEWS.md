# STLSoft - News


| Date                  | News Item                                                 |
| --------------------- | --------------------------------------------------------- |
| 28th October 2024     |   Release of STLSoft 1.10.12                              |
| 16th February 2024    |   Release of STLSoft 1.10.11                              |
| 16th February 2024    |   Release of STLSoft 1.10.10                              |
| 12th February 2024    |   Release of STLSoft 1.10.9                               |
| 6th February 2024     |   Release of STLSoft 1.10.8                               |
| 30th January 2024     |   Release of STLSoft 1.10.7                               |
| 28th January 2024     |   Release of STLSoft 1.10.6                               |
| 18th January 2024     |   Release of STLSoft 1.10.5                               |
| 16th January 2024     |   Release of STLSoft 1.10.4                               |
| 12th January 2024     |   Release of STLSoft 1.10.3                               |
| 3rd January 2024      |   Release of STLSoft 1.10.2                               |
| 16th December 2023    |   Release of [STLSoft 1.9.136](https://github.com/synesissoftware/STLSoft-1.9)  |
| 13th December 2023    |   Release of STLSoft 1.10.1                               |
| 26th April 2021       |   Release of STLSoft 1.10.1 beta 33                       |
| 26th April 2021       |   Release of STLSoft 1.10.1 beta 32                       |
| 2nd April 2021        |   Release of STLSoft 1.10.1 beta 31                       |
| 29th March 2021       |   Release of STLSoft 1.10.1 beta 30                       |
| 16th February 2021    |   Release of STLSoft 1.10.1 beta 29                       |
| 18th January 2021     |   Release of STLSoft 1.10.1 beta 28                       |
| 10th January 2021     |   Release of STLSoft 1.10.1 beta 27                       |
| 4th January 2021      |   Release of STLSoft 1.10.1 beta 26                       |
| 14th December 2020    |   Release of STLSoft 1.10.1 beta 25                       |
| 13th December 2020    |   Release of STLSoft 1.10.1 beta 24                       |
| 13th December 2020    |   Release of STLSoft 1.10.1 beta 23                       |
| 29th November 2020    |   Release of STLSoft 1.10.1 beta 22                       |
| 27th July 2020        |   Release of STLSoft 1.10.1 beta 21                       |
| 4th July 2020         |   Release of STLSoft 1.10.1 beta 20                       |
| 4th July 2020         |   Release of STLSoft 1.10.1 beta 19                       |
| 4th July 2020         |   Release of STLSoft 1.9.134                              |
| 13th June 2020        |   Release of STLSoft 1.9.133                              |
| 31st October 2019     |   Release of STLSoft 1.10.1 beta 18                       |
| 24th October 2019     |   Release of STLSoft 1.10.1 beta 17                       |
| 13th October 2019     |   Release of STLSoft 1.10.1 beta 16                       |
| 11th October 2019     |   Release of STLSoft 1.9.132                              |
| 13th September 2019   |   Release of STLSoft 1.10.1 beta 15                       |
| 4th August 2019       |   Release of STLSoft 1.10.1 beta 14                       |
| 16th April 2019       |   Release of STLSoft 1.10.1 beta 13                       |
| 26th December 2018    |   Release of STLSoft 1.10.1 beta 12                       |
| 22nd December 2018    |   Release of STLSoft 1.10.1 beta 11                       |
| 20th December 2018    |   Release of STLSoft 1.10.1 beta 10                       |
| 12th June 2018        |   Release of STLSoft 1.10.1 beta 9                        |
| 11th June 2018        |   Release of STLSoft 1.10.1 beta 8                        |
| 9th June 2018         |   Release of STLSoft 1.10.1 beta 7                        |
| 9th June 2018         |   Release of STLSoft 1.10.1 beta 6                        |
| 15th May 2017         |   Release of STLSoft 1.10.1 beta 5                        |
| 19th February 2017    |   Release of STLSoft 1.10.1 beta 3                        |
| 28th January 2017     |   Release of STLSoft 1.10.1 beta 2                        |
| 14th January 2017     |   Release of STLSoft 1.10.1 beta 1                        |
| 2nd November 2016     |   Release of STLSoft 1.9.131                              |
| 1st October 2016      |   Release of STLSoft 1.9.130                              |
| 17th July 2016        |   Release of STLSoft 1.9.129                              |
| 13th July 2016        |   Release of STLSoft 1.9.128                              |
| 6th May 2016          |   Release of STLSoft 1.9.127                              |
| 4th May 2016          |   Release of STLSoft 1.9.126                              |
| 14th February 2016    |   Release of STLSoft 1.9.125                              |
| 15th November 2015    |   Release of STLSoft 1.9.124                              |
| 15th November 2015    |   Release of STLSoft 1.9.123                              |
| 1st November 2015     |   Release of STLSoft 1.9.122                              |
| 25th September 2015   |   Release of STLSoft 1.9.121                              |
| 9th September 2015    |   Release of STLSoft 1.9.120                              |
| 26th August 2015      |   Release of STLSoft 1.9.119                              |
| 31st May 2014         |   Release of STLSoft 1.9.118                              |
| 16th February 2013    |   Release of STLSoft 1.9.117                              |
| 19th August 2012      |   Release of STLSoft 1.9.116                              |
| 31st July 2012        |   Release of STLSoft 1.9.115                              |
| 4th June 2012         |   Release of STLSoft 1.9.114                              |
| 4th June 2012         |   Release of STLSoft 1.9.113                              |
| 7th February 2012     |   Release of STLSoft 1.9.112                              |
| 30th November 2011    |   Release of STLSoft 1.9.111                              |
| 25th November 2011    |   Release of STLSoft 1.9.110                              |
| 13th August 2011      |   Release of STLSoft 1.9.109                              |
| 31st January 2011     |   Release of STLSoft 1.9.108                              |
| 30th January 2011     |   Release of STLSoft 1.9.107                              |
| 28th December 2010    |   Release of STLSoft 1.9.106                              |
| 27th December 2010    |   Release of STLSoft 1.9.105                              |
| 22nd November 2010    |   Release of STLSoft 1.9.104                              |
| 21st November 2010    |   Release of STLSoft 1.9.103                              |
| 8th November 2010     |   Release of STLSoft 1.9.102                              |
| 30th September 2010   |   Release of STLSoft 1.9.101                              |
| 12th August 2010      |   Release of STLSoft 1.9.100                              |
| 21st June 2010        |   Release of STLSoft 1.9.99                               |
| 7th June 2010         |   Release of STLSoft 1.9.98                               |
| 4th April 2010        |   Release of STLSoft 1.9.97                               |
| 10th March 2010       |   Release of STLSoft 1.9.96                               |
| 7th March 2010        |   Release of STLSoft 1.9.95                               |
| 5th March 2010        |   Release of STLSoft 1.9.94                               |
| 15th February 2010    |   Release of STLSoft 1.9.93                               |
| 11th February 2010    |   Release of STLSoft 1.9.92                               |
| 2nd February 2010     |   Release of STLSoft 1.9.91                               |
| 21st January 2010     |   Release of STLSoft 1.9.90                               |
| 19th January 2010     |   Release of STLSoft 1.9.89                               |
| 12th January 2010     |   Release of STLSoft 1.9.88                               |
| 11th August 2009      |   Release of STLSoft 1.9.87                               |
| 24th July 2009        |   Release of STLSoft 1.9.86                               |
| 16th June 2009        |   Release of STLSoft 1.9.85                               |
| 23rd May 2009         |   Release of STLSoft 1.9.84                               |
| 19th May 2009         |   Release of STLSoft 1.9.83                               |
| 15th May 2009         |   Release of STLSoft 1.9.82                               |
| 7th May 2009          |   Release of STLSoft 1.9.81                               |
| 6th May 2009          |   Release of STLSoft 1.9.80                               |
| 2nd May 2009          |   Release of STLSoft 1.9.79                               |
| 27th Apr 2009         |   Release of STLSoft 1.9.78                               |
| 9th Mar 2009          |   Release of STLSoft 1.10.1 alpha 10                      |
| 9th Mar 2009          |   Release of STLSoft 1.9.77                               |
| 6th Mar 2009          |   Release of STLSoft 1.10.1 alpha 9                       |
| 6th Mar 2009          |   Release of STLSoft 1.9.76                               |
| 26th Feb 2009         |   Release of STLSoft 1.10.1 alpha 8                       |
| 26th Feb 2009         |   Release of STLSoft 1.9.75                               |
| 13th Feb 2009         |   Release of STLSoft 1.9.74                               |
| 3rd Feb 2009          |   Release of STLSoft 1.9.73                               |
| 1st Feb 2009          |   Release of STLSoft 1.9.72                               |
| 28th Jan 2009         |   Release of STLSoft 1.9.71                               |
| 25th Jan 2009         |   Release of STLSoft 1.9.70                               |
| 23rd Jan 2009         |   Release of STLSoft 1.9.69                               |
| 19th Jan 2009         |   Release of STLSoft 1.9.68                               |
| 17th Jan 2009         |   Release of STLSoft 1.9.67                               |
| 4th Jan 2009          |   Release of STLSoft 1.9.66                               |
| 1st Jan 2009          |   Release of STLSoft 1.10.1 alpha 7                       |
| 1st Jan 2009          |   Release of STLSoft 1.9.65                               |
| 28th Dec 2008         |   Release of STLSoft 1.9.64                               |
| 19th Dec 2008         |   Release of STLSoft 1.10.1 alpha 6                       |
| 9th Dec 2008          |   Release of STLSoft 1.10.1 alpha 5                       |
| 9th Dec 2008          |   Release of STLSoft 1.9.63                               |
| 1st Dec 2008          |   Release of STLSoft 1.9.62                               |
| 19th Nov 2008         |   Release of STLSoft 1.10.1 alpha 4                       |
| 19th Nov 2008         |   Release of STLSoft 1.9.61                               |
| 29th Oct 2008         |   Release of STLSoft 1.10.1 alpha 3                       |
| 27th Oct 2008         |   Release of STLSoft 1.10.1 alpha 2                       |
| 27th Oct 2008         |   Release of STLSoft 1.9.60                               |
| 26th Oct 2008         |   Release of STLSoft 1.10.1 alpha 1                       |
| 25th Oct 2008         |   Release of STLSoft 1.9.59                               |
| 16th Oct 2008         |   Release of STLSoft 1.9.58                               |
| 10th Oct 2008         |   Release of STLSoft 1.9.57                               |
| 1st Oct 2008          |   Release of STLSoft 1.9.56                               |
| 29th Sep 2008         |   STLSoft website moves over to SourceForge               |
| 27th Sep 2008         |   Release of STLSoft 1.9.55                               |
| 15th Sep 2008         |   Release of STLSoft 1.9.54                               |
| 14th Sep 2008         |   Release of STLSoft 1.9.53                               |
| 11th Sep 2008         |   Release of STLSoft 1.9.52                               |
| 7th Sep 2008          |   Release of STLSoft 1.9.51                               |
| 3rd Sep 2008          |   Release of STLSoft 1.9.50                               |
| 2nd Sep 2008          |   Release of STLSoft 1.9.49                               |
| 23rd Aug 2008         |   Release of STLSoft 1.9.48                               |
| 12th Aug 2008         |   Release of STLSoft 1.9.47                               |
| 11th Aug 2008         |   Release of STLSoft 1.9.46                               |
| 8th June 2008         |   Release of STLSoft 1.9.45                               |
| 1st June 2008         |   Release of STLSoft 1.9.44                               |
| 31st May 2008         |   Release of STLSoft 1.9.43                               |
| 17th May 2008         |   Release of STLSoft 1.9.42                               |
| 13th May 2008         |   Release of STLSoft 1.9.41                               |
| 13th May 2008         |   Release of STLSoft 1.9.40                               |
| 11th May 2008         |   Release of STLSoft 1.9.39                               |
| 4th May 2008          |   Release of STLSoft 1.9.38                               |
| 3rd May 2008          |   Release of STLSoft 1.9.37                               |
| 30th April 2008       |   Release of STLSoft 1.9.36                               |
| 29th April 2008       |   Release of STLSoft 1.9.35                               |
| 25th April 2008       |   Release of STLSoft 1.9.34                               |
| 25th April 2008       |   Release of STLSoft 1.9.33                               |
| 22nd April 2008       |   Release of STLSoft 1.9.32                               |
| 13th April 2008       |   Release of STLSoft 1.9.31                               |
| 3rd April 2008        |   Release of STLSoft 1.9.30                               |
| 3rd April 2008        |   Release of STLSoft 1.9.29                               |
| 24th March 2008       |   Release of STLSoft 1.9.28                               |
| 17th March 2008       |   Release of STLSoft 1.9.27                               |
| 15th March 2008       |   Release of STLSoft 1.9.26                               |
| 9th March 2008        |   Release of STLSoft 1.9.25                               |
| 8th March 2008        |   Release of STLSoft 1.9.24                               |
| 20th February 2008    |   Release of STLSoft 1.9.23                               |
| 8th February 2008     |   Release of STLSoft 1.9.22                               |
| 5th February 2008     |   Release of STLSoft 1.9.21                               |
| 3rd February 2008     |   Release of STLSoft 1.9.20                               |
| 2nd February 2008     |   Release of STLSoft 1.9.19                               |
| 27th January 2008     |   Release of STLSoft 1.9.18                               |
| 5th January 2008      |   Release of STLSoft 1.9.17                               |
| 29th December 2007    |   Release of STLSoft 1.9.16                               |
| 24th December 2007    |   Release of STLSoft 1.9.15                               |
| 23rd December 2007    |   Release of STLSoft 1.9.14                               |
| 20th December 2007    |   Release of STLSoft 1.9.13                               |
| 19th December 2007    |   Release of STLSoft 1.9.12                               |
| 17th December 2007    |   Release of STLSoft 1.9.11                               |
| 10th December 2007    |   Release of STLSoft 1.9.10                               |
| 19th November 2007    |   Release of STLSoft 1.9.9                                |
| 18th November 2007    |   Release of STLSoft 1.9.8                                |
| 16th November 2007    |   Release of STLSoft 1.9.7                                |
| 25th September 2007   |   Release of STLSoft 1.9.6                                |
| 4th August 2007       |   Release of STLSoft 1.9.5                                |
| 2nd August 2007       |   Release of STLSoft 1.9.4                                |
| 29th July 2007        |   Release of STLSoft 1.9.3                                |
| 2nd June 2007         |   Release of STLSoft 1.9.2                                |
| 30th April 2007       |   Release of STLSoft 1.9.1 (for Extended STL, vol 1: CD)  |
| 29th March 2002       |   STLSoft project created                                 |


<!-- ########################### end of file ########################### -->

