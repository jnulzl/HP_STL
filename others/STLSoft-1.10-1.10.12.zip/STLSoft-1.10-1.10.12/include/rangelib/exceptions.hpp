/* STLSOFT:FILE_DEPRECATED */

#error This file is now obsolete. Instead include rangelib/error/exceptions.hpp

/* Compatibility
[<[STLSOFT-AUTO:NO-DOCFILELABEL]>]
[<[STLSOFT-AUTO:NO-UNITTEST]>]
*/

/* ///////////////////////////// end of file //////////////////////////// */

