/* STLSOFT:FILE_DEPRECATED */

#include <stlsoft/stlsoft.h>

#if _STLSOFT_VER >= 0x010a0200
# error This file is now obsolete. Instead include the precise header file that you require
#else

# ifndef _STLSOFT_SUPPRESS_WARNING_IN_OBSOLETE_FILES
#  ifdef STLSOFT_PPF_pragma_message_SUPPORT
#   pragma message(__FILE__ "(" STLSOFT_STRINGIZE(__LINE__) "): This file is now obsolete and will be removed in a forthcoming version. Instead include the precise header file that you require")
#  endif
# endif

# include <stlsoft/exception/os_exception.hpp>
# include <stlsoft/exception/project_exception.hpp>
# include <stlsoft/exception/root_exception.hpp>
# include <stlsoft/exception/throw_policies.hpp>
#endif

/* ///////////////////////////// end of file //////////////////////////// */

