#include <stlsoft/iterators/associative_select_iterator.hpp>
