# ifndef __SC_FOO
#  define __SC_FOO
template <class Arg>
struct sc_foo {
    void bar(Arg a);
};   
# endif
