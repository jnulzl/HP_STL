//#define __BUILDING_STLPORT 1
//#define _STLP_OWN_IOSTREAMS 1
#define _STLP_DEBUG 1

#if __MWERKS__ >= 0x3000
#include <MSLCarbonPrefix.h>
#endif