using _STLP_NEW_IO_NAMESPACE::basic_streambuf;
using _STLP_NEW_IO_NAMESPACE::streambuf;
#ifndef _STLP_NO_WIDE_STREAMS
using _STLP_NEW_IO_NAMESPACE::wstreambuf;
# endif
