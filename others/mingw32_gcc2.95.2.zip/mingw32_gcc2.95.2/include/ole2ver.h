#ifndef _OLE2VER_H
#define _OLE2VER_H
#define rmm 23
#define rup 639
#endif
