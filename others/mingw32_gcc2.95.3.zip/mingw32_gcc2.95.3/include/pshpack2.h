#ifndef RC_INVOKED
#pragma pack(push,2)
#endif
