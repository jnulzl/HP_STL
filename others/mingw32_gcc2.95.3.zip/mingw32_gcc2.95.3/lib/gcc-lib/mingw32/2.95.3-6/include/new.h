// -*- C++ -*- forwarding header.

#ifndef __NEW_H__
#define __NEW_H__

#include <new>

using std::new_handler;
using std::set_new_handler;

#endif // __NEW_H__
